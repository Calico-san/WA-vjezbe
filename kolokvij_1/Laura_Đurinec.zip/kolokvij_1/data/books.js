export const books = [
    {
        "id": 301,
        "naslov": "The Pragmatic Programmer",
        "autor": "Andrew Hunt, David Thomas",
        "godina_izdanja": 1999,
        "kategorije": [
            "Programming",
            "Software Engineering"
        ]
    },
    {
        "id": 302,
        "naslov": "Clean Code",
        "autor": "Robert C. Martin",
        "godina_izdanja": 2008,
        "kategorije": [
            "Programming",
            "Best Practices"
        ]
    },
    {
        "id": 303,
        "naslov": "Design Patterns",
        "autor": "Erich Gamma et al.",
        "godina_izdanja": 1994,
        "kategorije": [
            "Programming",
            "Architecture"
        ]
    }
]
