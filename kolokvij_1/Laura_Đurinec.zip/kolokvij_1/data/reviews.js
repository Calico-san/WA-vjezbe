export const reviews = [
    {
        "id": 501,
        "book_id": 301,
        "korisnik": "reader01",
        "ocjena": 5,
        "komentar": "Odlična i vrlo praktična knjiga!"
    },
    {
        "id": 502,
        "book_id": 303,
        "korisnik": "dev_master",
        "ocjena": 4,
        "komentar": "Obavezna literatura za programere."
    }
]